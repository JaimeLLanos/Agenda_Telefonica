package ais;
//import java.io.File;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.DefaultListModel;
import java.lang.NumberFormatException;
import javax.swing.JOptionPane;
import java.awt.event.WindowEvent;


public class Interfaz_de_Prueba extends javax.swing.JFrame {
    //private ArrayList<Contacto> lista= new ArrayList<>();
    //private File agenda;
    private Contacto c=new Contacto();
    private DefaultListModel<Contacto> d=new DefaultListModel();
    private DefaultListModel<Numero> d2=new DefaultListModel();
    private DefaultListModel<Contacto> d3=new DefaultListModel();
    private String string;
    private int num;
    private Agenda ag=new Agenda();
    public Interfaz_de_Prueba() {
        initComponents();
        PanelAniadir.setVisible(false);
        PanelModificar.setVisible(false);
        PanelBorrar.setVisible(false);
        PanelMostrar.setVisible(false);
        listaContacto.setListData(ag.getContactos().toArray());
            
        }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanelMain = new javax.swing.JDesktopPane();
        ventanaBuscar = new javax.swing.JTextField();
        buscar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        listaContacto = new javax.swing.JList();
        jLabel1 = new javax.swing.JLabel();
        añadir = new javax.swing.JButton();
        borrar = new javax.swing.JButton();
        vaciarAgenda = new javax.swing.JButton();
        modifContacto = new javax.swing.JButton();
        PanelAniadir = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        nombre = new javax.swing.JTextField();
        telefono = new javax.swing.JTextField();
        crearContacto = new javax.swing.JButton();
        añadirTelef = new javax.swing.JButton();
        atras = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        PanelModificar = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        modifNombre = new javax.swing.JButton();
        jTextField4 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        telefonos = new javax.swing.JList();
        modifTelef = new javax.swing.JButton();
        borrarTelef = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        PanelBorrar = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        PanelMostrar = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jList3 = new javax.swing.JList();
        nombreMostrar = new javax.swing.JLabel();
        modificar = new javax.swing.JButton();
        llamar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        PanelMain.setBackground(new java.awt.Color(255, 255, 255));

        buscar.setText("Buscar");
        buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarActionPerformed(evt);
            }
        });

        jScrollPane1.setViewportView(listaContacto);

        jLabel1.setText("Contacto");

        añadir.setText("Añadir");
        añadir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                añadirActionPerformed(evt);
            }
        });

        borrar.setText("Borrar");
        borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                borrarActionPerformed(evt);
            }
        });

        vaciarAgenda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ais/papelera2.png"))); // NOI18N
        vaciarAgenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vaciarAgendaActionPerformed(evt);
            }
        });

        modifContacto.setText("Modificar");
        modifContacto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modifContactoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelMainLayout = new javax.swing.GroupLayout(PanelMain);
        PanelMain.setLayout(PanelMainLayout);
        PanelMainLayout.setHorizontalGroup(
            PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMainLayout.createSequentialGroup()
                .addContainerGap(281, Short.MAX_VALUE)
                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelMainLayout.createSequentialGroup()
                        .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PanelMainLayout.createSequentialGroup()
                                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jScrollPane1)
                                    .addComponent(ventanaBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(PanelMainLayout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(buscar))
                                    .addGroup(PanelMainLayout.createSequentialGroup()
                                        .addGap(81, 81, 81)
                                        .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(modifContacto, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(borrar, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
                                                .addComponent(añadir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                            .addGroup(PanelMainLayout.createSequentialGroup()
                                .addGap(128, 128, 128)
                                .addComponent(jLabel1)))
                        .addGap(63, 63, 63))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelMainLayout.createSequentialGroup()
                        .addComponent(vaciarAgenda, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        PanelMainLayout.setVerticalGroup(
            PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMainLayout.createSequentialGroup()
                .addGap(97, 97, 97)
                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ventanaBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buscar))
                .addGap(13, 13, 13)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelMainLayout.createSequentialGroup()
                        .addComponent(añadir)
                        .addGap(18, 18, 18)
                        .addComponent(borrar)
                        .addGap(18, 18, 18)
                        .addComponent(modifContacto))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 61, Short.MAX_VALUE)
                .addComponent(vaciarAgenda))
        );
        PanelMain.setLayer(ventanaBuscar, javax.swing.JLayeredPane.DEFAULT_LAYER);
        PanelMain.setLayer(buscar, javax.swing.JLayeredPane.DEFAULT_LAYER);
        PanelMain.setLayer(jScrollPane1, javax.swing.JLayeredPane.DEFAULT_LAYER);
        PanelMain.setLayer(jLabel1, javax.swing.JLayeredPane.DEFAULT_LAYER);
        PanelMain.setLayer(añadir, javax.swing.JLayeredPane.DEFAULT_LAYER);
        PanelMain.setLayer(borrar, javax.swing.JLayeredPane.DEFAULT_LAYER);
        PanelMain.setLayer(vaciarAgenda, javax.swing.JLayeredPane.DEFAULT_LAYER);
        PanelMain.setLayer(modifContacto, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel2.setText("Nombre del contacto:");

        jLabel3.setText("Teléfono:");

        nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombreActionPerformed(evt);
            }
        });

        crearContacto.setText("Crear Contacto");
        crearContacto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                crearContactoActionPerformed(evt);
            }
        });

        añadirTelef.setText("->");
        añadirTelef.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                añadirTelefActionPerformed(evt);
            }
        });

        atras.setText("Atrás");
        atras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                atrasActionPerformed(evt);
            }
        });

        jLabel6.setText("Añadir otro teléfono");

        javax.swing.GroupLayout PanelAniadirLayout = new javax.swing.GroupLayout(PanelAniadir);
        PanelAniadir.setLayout(PanelAniadirLayout);
        PanelAniadirLayout.setHorizontalGroup(
            PanelAniadirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelAniadirLayout.createSequentialGroup()
                .addGroup(PanelAniadirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelAniadirLayout.createSequentialGroup()
                        .addGap(217, 217, 217)
                        .addGroup(PanelAniadirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(PanelAniadirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(crearContacto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(telefono)
                            .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(añadirTelef)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel6))
                    .addGroup(PanelAniadirLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(atras)))
                .addContainerGap(188, Short.MAX_VALUE))
        );
        PanelAniadirLayout.setVerticalGroup(
            PanelAniadirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelAniadirLayout.createSequentialGroup()
                .addGap(103, 103, 103)
                .addGroup(PanelAniadirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(76, 76, 76)
                .addGroup(PanelAniadirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(telefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(añadirTelef, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(78, 78, 78)
                .addComponent(crearContacto)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 110, Short.MAX_VALUE)
                .addComponent(atras)
                .addContainerGap())
        );

        jLabel4.setText("Nombre del Contacto:");

        jLabel5.setText("Teléfono:");

        modifNombre.setText("Modificar");
        modifNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modifNombreActionPerformed(evt);
            }
        });

        telefonos.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(telefonos);

        modifTelef.setText("Modificar");
        modifTelef.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modifTelefActionPerformed(evt);
            }
        });

        borrarTelef.setText("Borrar");

        jButton10.setText("Atrás");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jTextField1.setText("telefono nuevo");

        javax.swing.GroupLayout PanelModificarLayout = new javax.swing.GroupLayout(PanelModificar);
        PanelModificar.setLayout(PanelModificarLayout);
        PanelModificarLayout.setHorizontalGroup(
            PanelModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelModificarLayout.createSequentialGroup()
                .addGap(191, 191, 191)
                .addGroup(PanelModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(PanelModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(PanelModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(borrarTelef, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(modifTelef, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                    .addComponent(modifNombre, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTextField1))
                .addGap(250, 250, 250))
            .addGroup(PanelModificarLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jButton10)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelModificarLayout.setVerticalGroup(
            PanelModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelModificarLayout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addGroup(PanelModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(modifNombre)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addGroup(PanelModificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(PanelModificarLayout.createSequentialGroup()
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21)
                        .addComponent(modifTelef)
                        .addGap(18, 18, 18)
                        .addComponent(borrarTelef)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 157, Short.MAX_VALUE)
                .addComponent(jButton10)
                .addGap(24, 24, 24))
        );

        jLabel7.setText("¿Seguro que quieres borrar el contacto?");

        jButton12.setText("Si");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jButton13.setText("No");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelBorrarLayout = new javax.swing.GroupLayout(PanelBorrar);
        PanelBorrar.setLayout(PanelBorrarLayout);
        PanelBorrarLayout.setHorizontalGroup(
            PanelBorrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelBorrarLayout.createSequentialGroup()
                .addContainerGap(155, Short.MAX_VALUE)
                .addGroup(PanelBorrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(PanelBorrarLayout.createSequentialGroup()
                        .addComponent(jButton12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton13))
                    .addComponent(jLabel7))
                .addGap(152, 152, 152))
        );
        PanelBorrarLayout.setVerticalGroup(
            PanelBorrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelBorrarLayout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(jLabel7)
                .addGap(73, 73, 73)
                .addGroup(PanelBorrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton12)
                    .addComponent(jButton13))
                .addContainerGap(87, Short.MAX_VALUE))
        );

        jLabel8.setText("Nombre de contacto:");

        jLabel9.setText("Teléfono/s:");

        jList3.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "telefonos del contacto" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jScrollPane3.setViewportView(jList3);

        nombreMostrar.setText("nombre");

        modificar.setText("Modificar");
        modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarActionPerformed(evt);
            }
        });

        llamar.setText("Llamar");

        javax.swing.GroupLayout PanelMostrarLayout = new javax.swing.GroupLayout(PanelMostrar);
        PanelMostrar.setLayout(PanelMostrarLayout);
        PanelMostrarLayout.setHorizontalGroup(
            PanelMostrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMostrarLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(PanelMostrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel9)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(PanelMostrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3)
                    .addComponent(nombreMostrar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(77, 77, 77)
                .addGroup(PanelMostrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(llamar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(modificar))
                .addContainerGap(63, Short.MAX_VALUE))
        );
        PanelMostrarLayout.setVerticalGroup(
            PanelMostrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMostrarLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(PanelMostrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(nombreMostrar))
                .addGroup(PanelMostrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelMostrarLayout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(PanelMostrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(PanelMostrarLayout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(modificar)
                        .addGap(18, 18, 18)
                        .addComponent(llamar)))
                .addContainerGap(122, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelMain)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(8, 8, 8)
                    .addComponent(PanelAniadir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(PanelModificar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(PanelBorrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(PanelMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelMain)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(7, 7, 7)
                    .addComponent(PanelAniadir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(2, 2, 2)
                    .addComponent(PanelModificar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(PanelBorrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(PanelMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void añadirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_añadirActionPerformed
        PanelAniadir.setVisible(true);
        PanelMain.setVisible(false);
    }//GEN-LAST:event_añadirActionPerformed

    private void borrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_borrarActionPerformed
        PanelBorrar.setVisible(true);
        PanelMain.setVisible(false);
        num=listaContacto.getSelectedIndex();
        string=listaContacto.getName();
    }//GEN-LAST:event_borrarActionPerformed

    private void atrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_atrasActionPerformed
        PanelMain.setVisible(true);
        PanelAniadir.setVisible(false);
        this.telefono.setText(null);
        this.nombre.setText(null);
    }//GEN-LAST:event_atrasActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        PanelMain.setVisible(true);
        PanelModificar.setVisible(false);
        this.jTextField4.setText(null);
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        PanelMain.setVisible(true);
        PanelBorrar.setVisible(false);
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        JOptionPane.showMessageDialog(null,"Contacto borrado.");
        PanelMain.setVisible(true);
        PanelBorrar.setVisible(false);
        listaContacto.remove(num);
        ag.Eliminar(c);
    }//GEN-LAST:event_jButton12ActionPerformed

    private void modificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarActionPerformed
        PanelModificar.setVisible(true);
        PanelMostrar.setVisible(false);
    }//GEN-LAST:event_modificarActionPerformed

    private void crearContactoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_crearContactoActionPerformed
        try{
        String s;
        if (nombre.getText()==null) {
            s=telefono.getText();
        } else { s=nombre.getText(); }
        Numero numero=new Numero();
        numero.setNumero(Integer.parseInt(telefono.getText()));
        Contacto o=new Contacto(s, numero); 
        c=o;
        JOptionPane.showMessageDialog(null,"Contacto creado");
        ag.Anadir(c);
        Contacto array []=new Contacto[ag.getContactos().size()];
        for (int i=0; i<array.length ;i++)
               array[i]=ag.getContactos().get(i);
        this.listaContacto.setListData(array);
        PanelAniadir.setVisible(false);
        PanelMain.setVisible(true);
        this.nombre.setText(null);
        this.telefono.setText(null);
        c.eliminarListaNumero();
        c.set_nombre("");
        } catch (java.lang.NumberFormatException ex){
            JOptionPane.showMessageDialog(null,"Rellena bien los campos");
        }
    }//GEN-LAST:event_crearContactoActionPerformed

    private void nombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombreActionPerformed
        
    }//GEN-LAST:event_nombreActionPerformed

    
    private void buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarActionPerformed
        try {
        ArrayList aux=ag.Buscar(ventanaBuscar.getText());
        d=null;
        for (int i=1; i<aux.size(); i++){
            d.addElement((Contacto) aux.get(i));
        }
        
        } catch (java.lang.NumberFormatException ex){
            JOptionPane.showMessageDialog(null,"Error al buscar, no hay datos");
        }
        
        
    }//GEN-LAST:event_buscarActionPerformed

    private void añadirTelefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_añadirTelefActionPerformed
        Numero num=new Numero();
        num.setNumero(Integer.parseInt(this.telefono.getText()));
        c.anadirNumero(num);
        this.telefono.setText(null);
    }//GEN-LAST:event_añadirTelefActionPerformed

    private void modifTelefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modifTelefActionPerformed
        int n=this.telefonos.getSelectedIndex();
        telefonos.getComponent(n);
        //Contacto c2=ag.BuscarContacto(this.jTextField4.getText());
        //c2.modificarNumero(null, Integer.parseInt(jTextField1.getText()));
    }//GEN-LAST:event_modifTelefActionPerformed

    private void vaciarAgendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vaciarAgendaActionPerformed
        ag.Vaciar();
    }//GEN-LAST:event_vaciarAgendaActionPerformed

    private void modifContactoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modifContactoActionPerformed
        PanelMostrar.setVisible(true);
        PanelMain.setVisible(false);
        String s=listaContacto.getName();
        //int n=jList3.getSelectedIndex();
        //String s=modelo2.getElementAt(n);
        //c=ag.BuscarContacto(s);
        this.nombreMostrar.setText(c.getNombre());
        
        for (int i=1; i<c.getNumeros().size(); i++){
            d2.addElement(c.getNumeros().get(i));
        }
        this.jList3.setModel(d2);
        
    }//GEN-LAST:event_modifContactoActionPerformed

    private void modifNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modifNombreActionPerformed
        //Contacto c2=ag.BuscarContacto(this.nombreMostrar.getText());
        //c2.set_nombre(this.jTextField4.getText());
        
    }//GEN-LAST:event_modifNombreActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Interfaz_de_Prueba().setVisible(true);
            }
        });
    }
    private javax.swing.JOptionPane ventanita;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PanelAniadir;
    private javax.swing.JPanel PanelBorrar;
    private javax.swing.JDesktopPane PanelMain;
    private javax.swing.JPanel PanelModificar;
    private javax.swing.JPanel PanelMostrar;
    private javax.swing.JButton atras;
    private javax.swing.JButton añadir;
    private javax.swing.JButton añadirTelef;
    private javax.swing.JButton borrar;
    private javax.swing.JButton borrarTelef;
    private javax.swing.JButton buscar;
    private javax.swing.JButton crearContacto;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JList jList3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JList listaContacto;
    private javax.swing.JButton llamar;
    private javax.swing.JButton modifContacto;
    private javax.swing.JButton modifNombre;
    private javax.swing.JButton modifTelef;
    private javax.swing.JButton modificar;
    private javax.swing.JTextField nombre;
    private javax.swing.JLabel nombreMostrar;
    private javax.swing.JTextField telefono;
    private javax.swing.JList telefonos;
    private javax.swing.JButton vaciarAgenda;
    private javax.swing.JTextField ventanaBuscar;
    // End of variables declaration//GEN-END:variables
}
