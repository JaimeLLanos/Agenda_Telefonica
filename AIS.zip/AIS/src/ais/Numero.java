package ais;

public class Numero {
   private int numero;
    
    public int getNumero(){
        return this.numero;
    }
    
    public void setNumero(int numero){
        this.numero=numero;
    }
    
   @Override
    public String toString (){
        return Integer.toString(this.getNumero());
    }
            
}