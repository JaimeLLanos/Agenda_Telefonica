/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica;

import java.util.ArrayList;

/**
 *
 * @author yoel
 */
public class Principal {
    
    public static void main(String[] args) {
        
        Agenda agenda = new Agenda();
        Agenda agendaAux= new Agenda();
        ArrayList<Contacto> contactos=new ArrayList<>();
        agendaAux.setContactos(contactos);
        
        agenda.cargarConRuta("agenda.obj");
        /*
        Contacto contacto1=new Contacto("Pepe");
        Contacto contacto2= new Contacto("Luis");
        Contacto contacto3=new Contacto("Antonio");
        
        Numero n1=new Numero(666555444);
        Numero n2=new Numero(654632698);
        Numero n3 = new Numero(644688611);
        Numero n4 = new Numero(699855122);
        
        contacto1.anadirNumero(n1);
        contacto2.anadirNumero(n2);
        contacto3.anadirNumero(n3);
        contacto1.anadirNumero(n4);
        
        agenda.Anadir(contacto1);
        agenda.Anadir(contacto2);
        agenda.Anadir(contacto3);
        */
        
        agenda.Mostrar();
        
        agendaAux.setContactos(agenda.Buscar("a"));
        agendaAux.Mostrar();
        
        
        /*
        Agenda agendaAux=new Agenda();
        agendaAux.setContactos(agenda.Buscar(contacto1.getNombre()));
        
        agendaAux.Mostrar();
                */
        //agenda.vaciarAgenda("agenda.obj");
        
        
    }
    
}
