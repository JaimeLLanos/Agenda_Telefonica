/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica;

import practica.Contacto;
import practica.Numero;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author yoel
 */
public class ContactoTest {
    
    public ContactoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of set_nombre method, of class Contacto.
     */
    @Test
    public void testSet_nombre() {
        System.out.println("set_nombre");
        String nomb = "Yoel";
        Contacto instance = new Contacto();
        instance.set_nombre(nomb);
        
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of anadirNumero method, of class Contacto.
     */
    @Test
    public void testAnadirNumero() {
        System.out.println("anadirNumero");
        Numero numero = null;
        Contacto instance = new Contacto();
        instance.anadirNumero(numero);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of eliminarNumero method, of class Contacto.
     */
    @Test
    public void testEliminarNumero() {
        System.out.println("eliminarNumero");
        Numero numero = null;
        Contacto instance = new Contacto();
        instance.eliminarNumero(numero);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of compareTo method, of class Contacto.
     */
    @Test
    public void testCompareTo() {
        System.out.println("compareTo");
        Contacto o = new Contacto("Yoel",null);
        Contacto instance = new Contacto("Yoel",null);
        int expResult = 0;
        int result = instance.getNombre().compareTo(o.getNombre());
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of ModificarNumero method, of class Contacto.
     */
    @Test
    public void testModificarNumero() {
        System.out.println("ModificarNumero");
        Numero viejo = null;
        Numero nuevo = null;
        Contacto instance = new Contacto();
        instance.ModificarNumero(viejo, nuevo);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getNumeros method, of class Contacto.
     */
    @Test
    public void testGetNumeros() {
        System.out.println("getNumeros");
        Contacto instance = new Contacto("Yoel");
        ArrayList<Numero> expResult = new ArrayList<>();
        ArrayList<Numero> result = instance.getNumeros();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getNombre method, of class Contacto.
     */
    @Test
    public void testGetNombre() {
        System.out.println("getNombre");
        Contacto instance = new Contacto("Yoel");
        String expResult = "Yoel";
        String result = instance.getNombre();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

   
    
}
