/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica;

import practica.Agenda;
import practica.Contacto;
import practica.Numero;
import java.io.File;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author yoel
 */
public class AgendaTest {
    
    public AgendaTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getContactos method, of class Agenda.
     */
    @Test
    public void testGetContactos() {
        System.out.println("getContactos");
        Agenda instance = new Agenda();
        ArrayList<Contacto> expResult = new ArrayList<>();
        ArrayList<Contacto> result = instance.getContactos();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setContactos method, of class Agenda.
     */
    @Test
    public void testSetContactos() {
        System.out.println("setContactos");
        ArrayList<Contacto> contactos = null;
        Agenda instance = new Agenda();
        instance.setContactos(contactos);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of Consultar method, of class Agenda.
     */
    @Test
    public void testConsultar() {
        System.out.println("Consultar");
        String nombre = "Pepe";
        Agenda instance = new Agenda();
        instance.Consultar(nombre);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of Anadir method, of class Agenda.
     */
    @Test
    public void testAnadir() {
        System.out.println("Anadir");
        Numero numero= new Numero(666555444);
        Contacto contacto = new Contacto("Yoel",numero);
        Agenda instance = new Agenda();
        instance.Anadir(contacto);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of Buscar method, of class Agenda.
     */
    @Test
    public void testBuscar() {
        System.out.println("Buscar");
        String nombre = "Yoel";
        Agenda instance = new Agenda();
        ArrayList<Contacto> expResult = instance.getContactos();
        ArrayList<Contacto> result = instance.Buscar(nombre);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of Mostrar method, of class Agenda.
     */
    @Test
    public void testMostrar() {
        System.out.println("Mostrar");
        Agenda instance = new Agenda();
        instance.Mostrar();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of Vaciar method, of class Agenda.
     */
    @Test
    public void testVaciar() {
        System.out.println("Vaciar");
        Agenda instance = new Agenda();
        instance.Vaciar();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of Eliminar method, of class Agenda.
     */
    @Test
    public void testEliminar() {
        System.out.println("Eliminar");
        Contacto contacto = new Contacto("Yoel",new Numero(666555444));
        Agenda instance = new Agenda();
        instance.Eliminar(contacto);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of Modificar method, of class Agenda.
     */
    @Test
    public void testModificar_0args() {
        System.out.println("Modificar");
        Agenda instance = new Agenda();
        instance.Modificar();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of Modificar method, of class Agenda.
     */
    @Test
    public void testModificar_Contacto() {
        System.out.println("Modificar");
        Contacto contacto = new Contacto("Yoel",new Numero(666555444));
        Agenda instance = new Agenda();
        instance.Modificar(contacto);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of cargar method, of class Agenda.
     */
    @Test
    public void testCargar() {
        System.out.println("cargar");
        File fichero = new File("agenda.obj");
        Agenda instance = new Agenda();
        instance.cargar(fichero);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of cargarConRuta method, of class Agenda.
     */
    @Test
    public void testCargarConRuta() {
        System.out.println("cargarConRuta");
        String ruta = "agenda.obj";
        Agenda instance = new Agenda();
        instance.cargarConRuta(ruta);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of vaciarAgenda method, of class Agenda.
     */
    @Test
    public void testVaciarAgenda() {
        System.out.println("vaciarAgenda");
        String ruta = "agenda.data";
        Agenda instance = new Agenda();
        instance.vaciarAgenda(ruta);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
