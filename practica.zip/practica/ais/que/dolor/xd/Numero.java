/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.ais.que.dolor.xd;

import java.io.Serializable;

/**
 *
 * @author yoel
 */
public class Numero implements Serializable {
   private int numero;
   private int prefijoNacional;
   
   public Numero(int numero){
       this.setNumero(numero);
   }
   public Numero(int numero,int prefijoNacional){
       this.numero=numero;
       this.prefijoNacional=prefijoNacional;
   }

    Numero() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
           
    
    public int getNumero(){
        return this.numero;
    }
    
    public void setNumero(int numero){
        this.numero=numero;
    }
    
    public void setPrefijoNacional(int prefijo){
        this.prefijoNacional=prefijo;
    }
    public int getPrefijoNacional(){
        return this.prefijoNacional;
    }
    
   @Override
    public String toString (){
        return "+"+Integer.toString(this.getPrefijoNacional())+" "+Integer.toString(this.getNumero());
    }
            
}
